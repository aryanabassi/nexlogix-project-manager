NEXLOGIX TECHNOLOGIES - VERCEL EDITION

Deploy:
1. Extract this ZIP.
2. Put the files in a GitHub repository (index.html + assets/logo.jpeg).
3. Open Vercel and choose Add New -> Project.
4. Import the GitHub repository.
5. Framework Preset: Other.
6. Build Command: leave empty.
7. Output Directory: leave empty.
8. Click Deploy.
9. Open the generated vercel.app address.

Login:
Username: admin
Password: Nexlogix@123

This edition is pure HTML/CSS/JavaScript, so it works on Vercel without PHP or a database.
Data is stored in the browser localStorage. Use Backup & Restore to download/restore JSON data.
The login is a client-side convenience login, not secure server-side authentication.
